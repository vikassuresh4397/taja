// index.js

//  import the crypto module



//  get a commands using process.argv


// complete the  function



switch (operation) {
  
  default:
    console.log("Invalid operation");
}
