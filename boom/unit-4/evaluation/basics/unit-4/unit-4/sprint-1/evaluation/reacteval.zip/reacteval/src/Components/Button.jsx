// enter code here
// button should have mentioned styling
// do a default export

function Button(){
    const style={
        backgroundColor:"tomato",
        padding:"1rem"
    }
    return <div>
        <button style={style}>click me </button>
    </div>
}
export default Button;